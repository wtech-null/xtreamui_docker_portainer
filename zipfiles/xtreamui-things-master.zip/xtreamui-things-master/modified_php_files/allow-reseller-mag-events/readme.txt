edited these php files to allow mag events for resellers

put these into admin folder.
